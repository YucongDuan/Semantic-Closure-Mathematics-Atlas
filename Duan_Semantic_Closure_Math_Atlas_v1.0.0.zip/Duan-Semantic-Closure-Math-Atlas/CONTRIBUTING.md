# Contributing

Contributions should preserve the three-layer status model, include a machine-readable proof manifest, and pass `python -m unittest discover -s tests` plus `python semantic_closure_cli.py audit`.
