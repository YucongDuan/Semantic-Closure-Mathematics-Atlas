#!/usr/bin/env python3
"""Exact verifier and bounded search tool for divisor certificates in the
Erdos-Straus equation 4/n = 1/x + 1/y + 1/z.

This program verifies *local certificates*. It does not turn a bounded search
into a proof for all n.
"""
from __future__ import annotations

import argparse
import json
import math
from fractions import Fraction
from typing import Dict, Iterable, Optional, Tuple


def divisors(value: int) -> Iterable[int]:
    if value <= 0:
        return []
    small = []
    large = []
    root = math.isqrt(value)
    for d in range(1, root + 1):
        if value % d == 0:
            small.append(d)
            q = value // d
            if q != d:
                large.append(q)
    return small + large[::-1]


def verify_certificate(n: int, a: int, b: int, k: int) -> Dict[str, object]:
    errors = []
    if min(n, a, b, k) <= 0:
        errors.append("n, a, b and k must all be positive integers")
    source = a + b * n
    if source % k != 0:
        errors.append("k does not divide a + b*n")
        q = None
    else:
        q = source // k
    if k % 4 != 3:
        errors.append("k is not congruent to 3 modulo 4")
    if n % 4 != 1:
        errors.append("this certificate compiler is intended for n congruent to 1 modulo 4")

    x = y = z = None
    if q is not None:
        first = q * (n + k)
        second = n * q * (n + k)
        if first % (4 * b) != 0:
            errors.append("4*b does not divide q*(n+k)")
        if second % (4 * a) != 0:
            errors.append("4*a does not divide n*q*(n+k)")
        if (n + k) % 4 != 0:
            errors.append("n+k is not divisible by 4")
        if not errors:
            x = (n + k) // 4
            y = first // (4 * b)
            z = second // (4 * a)
            if min(x, y, z) <= 0:
                errors.append("compiled denominators are not all positive")
            elif Fraction(4, n) != Fraction(1, x) + Fraction(1, y) + Fraction(1, z):
                errors.append("exact rational identity failed")

    return {
        "valid": not errors,
        "n": n,
        "a": a,
        "b": b,
        "k": k,
        "q": q,
        "source": source,
        "x": x,
        "y": y,
        "z": z,
        "errors": errors,
    }


def search_certificate(n: int, a_max: int = 20, b_max: int = 20) -> Optional[Dict[str, object]]:
    if n <= 0:
        raise ValueError("n must be positive")
    for a in range(1, a_max + 1):
        for b in range(1, b_max + 1):
            source = a + b * n
            for k in divisors(source):
                if k % 4 != 3:
                    continue
                result = verify_certificate(n, a, b, k)
                if result["valid"]:
                    return result
    return None


def scale_solution(divisor: int, n: int, triple: Tuple[int, int, int]) -> Tuple[int, int, int]:
    if n % divisor != 0:
        raise ValueError("divisor must divide n")
    factor = n // divisor
    return tuple(factor * t for t in triple)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)

    p_verify = sub.add_parser("verify", help="verify one certificate")
    p_verify.add_argument("n", type=int)
    p_verify.add_argument("a", type=int)
    p_verify.add_argument("b", type=int)
    p_verify.add_argument("k", type=int)

    p_search = sub.add_parser("search", help="bounded search for one certificate")
    p_search.add_argument("n", type=int)
    p_search.add_argument("--a-max", type=int, default=20)
    p_search.add_argument("--b-max", type=int, default=20)

    p_range = sub.add_parser("range", help="bounded verification over n congruent to 1 mod 4")
    p_range.add_argument("limit", type=int)
    p_range.add_argument("--a-max", type=int, default=20)
    p_range.add_argument("--b-max", type=int, default=20)

    args = parser.parse_args()
    if args.command == "verify":
        result = verify_certificate(args.n, args.a, args.b, args.k)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0 if result["valid"] else 1

    if args.command == "search":
        result = search_certificate(args.n, args.a_max, args.b_max)
        print(json.dumps(result or {"valid": False, "n": args.n, "message": "no certificate in bounded window"}, ensure_ascii=False, indent=2))
        return 0 if result else 2

    failures = []
    checked = 0
    for n in range(5, args.limit + 1, 4):
        checked += 1
        if search_certificate(n, args.a_max, args.b_max) is None:
            failures.append(n)
    print(json.dumps({
        "checked": checked,
        "limit": args.limit,
        "a_max": args.a_max,
        "b_max": args.b_max,
        "undetected": failures,
        "note": "A bounded search is empirical evidence, not a universal proof."
    }, ensure_ascii=False, indent=2))
    return 0 if not failures else 3


if __name__ == "__main__":
    raise SystemExit(main())
