#!/usr/bin/env python3
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
import argparse, os, webbrowser

ROOT=Path(__file__).resolve().parent

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--host',default='127.0.0.1'); ap.add_argument('--port',type=int,default=8000); ap.add_argument('--open',action='store_true')
    args=ap.parse_args(); os.chdir(ROOT)
    url=f'http://{args.host}:{args.port}/web/'
    print(f'Serving {ROOT} at {url}')
    if args.open: webbrowser.open(url)
    ThreadingHTTPServer((args.host,args.port),SimpleHTTPRequestHandler).serve_forever()
if __name__=='__main__': main()
