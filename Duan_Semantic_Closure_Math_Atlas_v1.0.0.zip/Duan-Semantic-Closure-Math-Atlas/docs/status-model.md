# Three-layer status model

Every achievement card separates:

- `semantic_status`: the status claimed inside the semantic-closure framework;
- `compilation_status`: whether a mapping to the conventional statement is documented;
- `classical_status`: the public external status of the conventional mathematical problem.

This is not a ranking. It is a provenance model that prevents one layer from silently replacing another.
