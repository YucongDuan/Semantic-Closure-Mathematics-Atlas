# Adding a proof manifest

1. Copy `proofs/navier-stokes.json`.
2. Give the proof a unique lowercase `id`.
3. State the bilingual semantic object and closure topology.
4. Supply a closure chain with at least three stages.
5. Fill K1–K10 interfaces and evidence locations.
6. Add report/tool paths under `artifacts`.
7. Run `python semantic_closure_cli.py validate <id>`.
8. Add the card to `data/achievements.json`.
