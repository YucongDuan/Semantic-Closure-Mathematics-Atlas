# Methodology / 方法论

The source methodology treats an abstract order not as a scalar magnitude but as a generative, containment, and eliminability relation. A proof artifact therefore records:

- finite or locally finite realization;
- unitization of the semantic object;
- a maximal unresolved generative root;
- endogenous elimination of that root and all descendants;
- context congruence;
- non-regeneration;
- a base-closure topology;
- fidelity compilation.

## K1
Finite or locally finite realization.
## K2
Finite descendant types.
## K3
Independent generative precedence.
## K4
Endogenous elimination.
## K5
Descendant completeness.
## K6
Context congruence.
## K7
Non-regeneration.
## K8
Well-founded or invariant closure.
## K9
Independent base topology.
## K10
Fidelity compilation.
