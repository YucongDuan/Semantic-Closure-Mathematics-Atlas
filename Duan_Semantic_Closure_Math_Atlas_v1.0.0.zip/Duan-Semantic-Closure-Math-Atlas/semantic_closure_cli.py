#!/usr/bin/env python3
"""CLI for the Duan Semantic Closure Mathematics Atlas.

Standard-library only. Commands:
  list
  show <proof-id>
  validate [proof-id|path]
  audit
"""
from __future__ import annotations
import argparse, json, sys
from pathlib import Path

ROOT=Path(__file__).resolve().parent
PROOFS=ROOT/'proofs'
REQUIRED={f'K{i}' for i in range(1,11)}

def load(path:Path):
    return json.loads(path.read_text(encoding='utf-8'))

def proof_path(value:str)->Path:
    p=Path(value)
    if p.exists(): return p
    q=PROOFS/f'{value}.json'
    if q.exists(): return q
    raise FileNotFoundError(value)

def validate_manifest(m:dict,base:Path=ROOT):
    errors=[]
    for key in ['schema_version','id','title','domain','semantic_statement','closure_topology','closure_chain','status','interfaces','artifacts']:
        if key not in m: errors.append(f'missing key: {key}')
    ids={x.get('id') for x in m.get('interfaces',[])}
    missing=REQUIRED-ids
    if missing: errors.append('missing interfaces: '+','.join(sorted(missing)))
    for art in m.get('artifacts',[]):
        p=art.get('path')
        if p and not (base/p).exists(): errors.append(f'missing artifact: {p}')
    zh=m.get('closure_chain',{}).get('zh',[]); en=m.get('closure_chain',{}).get('en',[])
    if len(zh)<3 or len(en)<3: errors.append('closure chain must have >=3 entries in both languages')
    return errors

def cmd_list(_):
    for p in sorted(PROOFS.glob('*.json')):
        m=load(p); print(f"{m['id']:<18} {m['title']['zh']} / {m['title']['en']}")

def cmd_show(args):
    print(json.dumps(load(proof_path(args.value)),ensure_ascii=False,indent=2))

def cmd_validate(args):
    targets=[proof_path(args.value)] if args.value else sorted(PROOFS.glob('*.json'))
    failed=0
    for p in targets:
        m=load(p); errors=validate_manifest(m)
        if errors:
            failed+=1; print(f'[FAIL] {p.name}')
            for e in errors: print('  -',e)
        else: print(f'[OK]   {p.name}')
    return failed

def cmd_audit(_):
    total=0; ok=0
    for p in sorted(PROOFS.glob('*.json')):
        total+=1
        if not validate_manifest(load(p)): ok+=1
    print(f'{ok}/{total} manifests passed the K1-K10 and artifact audit')
    return 0 if ok==total else 1

def main():
    ap=argparse.ArgumentParser()
    sp=ap.add_subparsers(dest='cmd',required=True)
    sp.add_parser('list').set_defaults(fn=cmd_list)
    sh=sp.add_parser('show'); sh.add_argument('value'); sh.set_defaults(fn=cmd_show)
    va=sp.add_parser('validate'); va.add_argument('value',nargs='?'); va.set_defaults(fn=cmd_validate)
    sp.add_parser('audit').set_defaults(fn=cmd_audit)
    args=ap.parse_args(); result=args.fn(args); raise SystemExit(result or 0)
if __name__=='__main__': main()
