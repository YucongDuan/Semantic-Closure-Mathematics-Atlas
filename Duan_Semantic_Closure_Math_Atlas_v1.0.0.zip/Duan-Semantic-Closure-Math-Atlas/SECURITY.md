# Security

The web application is static and makes no outbound network requests. The server is Python's standard-library development server; bind it to localhost unless you intentionally deploy it behind a hardened web server.
