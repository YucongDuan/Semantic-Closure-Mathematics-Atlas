# Changelog

## 1.0.0 - 2026-08-06
- Initial bilingual offline atlas.
- Nine achievement/methodology cards.
- K1–K10 manifest auditor.
- Interactive closure topology graph.
- Navier–Stokes transport–constraint–viscous-elimination closure module.
