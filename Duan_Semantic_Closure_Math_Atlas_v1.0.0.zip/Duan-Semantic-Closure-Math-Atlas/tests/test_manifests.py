import json, unittest
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from semantic_closure_cli import validate_manifest

class ManifestTests(unittest.TestCase):
    def test_all_manifests(self):
        for path in sorted((ROOT/'proofs').glob('*.json')):
            with self.subTest(path=path.name):
                m=json.loads(path.read_text(encoding='utf-8'))
                self.assertEqual(validate_manifest(m),[])
    def test_achievement_ids_unique(self):
        data=json.loads((ROOT/'data/achievements.json').read_text(encoding='utf-8'))
        ids=[x['id'] for x in data]
        self.assertEqual(len(ids),len(set(ids)))

if __name__=='__main__': unittest.main()
